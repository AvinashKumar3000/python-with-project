from utils.csv_storage import loadCSV, FIELDS, save2CSV
import pandas as pd

class InventoryService:
    data = []
    def getAll(): 
        rows = loadCSV()
        df = pd.DataFrame(rows)
        print(df)
        
    def insert():
        di = {}
        for field in FIELDS:
            di[field] = input(field+" :")
        rows = loadCSV()
        existing_data = [ x for x in rows ]
        existing_data.append(di)
        save2CSV(existing_data)
        print("added entry successfully")

    def update(): 
        sno = int(input("enter sno to be updated"))
        # TODO 

    def remove(): 
        sno = int(input("enter sno to be updated"))
        # TODO

    def totalExpense():
        # TODO
        pass

