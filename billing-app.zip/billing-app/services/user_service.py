from utils.json_storage import getJsonInfo

class UserService:
    def getInfo():
        data = getJsonInfo()
        for key in data:
            print(f"{key:<10}:{data[key]}")

    