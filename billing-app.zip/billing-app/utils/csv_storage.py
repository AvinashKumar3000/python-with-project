import csv

CSV_PATH = './data/data.csv'
FIELDS = ("sno","date","time","item","quantity","price","total")

def loadCSV():
    try:
        with open(CSV_PATH,'r') as f:
            reader = csv.DictReader(f)
            rows = [ row for row in reader ]
            return rows
    except FileNotFoundError as e:
        print(e)

def save2CSV(data):
    try:
        with open(CSV_PATH,'w',newline="") as f:
            writer = csv.DictWriter(f,fieldnames=FIELDS)
            writer.writeheader()
            writer.writerows(data)
    except FileNotFoundError as e:
        print(e)