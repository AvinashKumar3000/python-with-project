# utils/json_storage.py

import json

def getJsonInfo():
	try:
		with open("./data/data.json","r") as f:
			info = json.load(f)
			return info
	except FileNotFoundError as e:
		print(e)