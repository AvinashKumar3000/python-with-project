from constants.app_info import APP_INFO
from art import tprint

def menu():
    tprint("tea billing app",font="big")
    for key in APP_INFO:
        title = APP_INFO[key]['title']
        print(key, title)
    print("?. enter other number to exit")

def run():
    while True:
        menu()
        choice = int(input("\nEnter your choice :"))
        try:
            di = APP_INFO[choice]
            title = di['title']
            fn = di['fn']
            print()
            print(f"[ {title:^20} ]")
            print()
            fn()
        except KeyError as e:
            print("Thank you for using this app.")
            exit()
        print("----------------------------------------------")
        input("Press enter to continue")

if __name__=="__main__":
    run()