from services.user_service import UserService
from services.inventory_service import InventoryService

APP_INFO = {
    1: { 
        "title": "get app info",
        "fn": UserService.getInfo
    },
    2: { 
        "title": "inventory: get details",
        "fn": InventoryService.getAll
    },
    3: { 
        "title": "inventory: insert entry",
        "fn": InventoryService.insert
    },
}