class InvalidAmountError(Exception):
    """Raised when amount is invalid."""
    pass

class InvalidCategoryError(Exception):
    """Raised when category is invalid."""
    pass
